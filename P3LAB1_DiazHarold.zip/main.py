r = int(input())
g = int(input())
b = int(input())

if r < g and r < b:
    smallest_value = r
elif g < r and g < b:
    smallest_value = g
else:
    smallest_value = b
    
grayless_r = r - smallest_value
grayless_g = g - smallest_value
grayless_b = b - smallest_value

print(grayless_r, grayless_g, grayless_b)